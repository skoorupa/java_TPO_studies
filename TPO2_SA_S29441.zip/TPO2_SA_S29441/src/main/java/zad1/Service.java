/**
 *
 *  @author Skorupski Adam S29441
 *
 */

package zad1;


import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.stream.Collectors;

public class Service {
    private String kraj;
    private static String openWeatherApiKey = "6940a577d4f80e42cee5060a835e7063";
    private static String weatherApi = "https://api.openweathermap.org/data/2.5/weather?lat=%s&lon=%s&units=metric&appid="+openWeatherApiKey;
    private static String geocoderApi = "http://api.openweathermap.org/geo/1.0/direct?q=%s,%s&limit=1&appid="+openWeatherApiKey;

    public Service(String kraj) {
        this.kraj = kraj;
    }

    public String getWeather(String miasto) {
        InputStream geocoderInputStream = null;
        try {
            geocoderInputStream = new URL(String.format(geocoderApi, miasto, kraj)).openConnection().getInputStream();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        String geocoderJson = new BufferedReader(new InputStreamReader(geocoderInputStream)).lines().collect(Collectors.joining());
        System.out.println(geocoderJson);
        return geocoderJson;
    }

    public Double getRateFor(String kod_waluty) {
        return 0d;
    }

    public Double getNBPRate() {
        return 0d;
    }
}

class LatLon {
    private String lat;
    private String lon;

    public LatLon(String lat, String lon) {
        this.lat = lat;
        this.lon = lon;
    }

    public String getLat() {
        return lat;
    }

    public String getLon() {
        return lon;
    }
}