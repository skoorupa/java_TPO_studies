package zad1;

public enum CallMethod {
    MESSAGE, LOGIN, LOGOUT
}
