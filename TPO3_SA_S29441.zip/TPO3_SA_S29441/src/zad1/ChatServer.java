/**
 *
 *  @author Skorupski Adam S29441
 *
 */

package zad1;


public class ChatServer {
}
