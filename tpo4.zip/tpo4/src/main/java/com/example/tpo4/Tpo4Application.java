package com.example.tpo4;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Tpo4Application {

	public static void main(String[] args) {
		SpringApplication.run(Tpo4Application.class, args);
	}

}
